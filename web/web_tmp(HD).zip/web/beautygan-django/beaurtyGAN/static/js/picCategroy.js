function changeCategory(obj){
    obj.style.border = 'solid 1px rgba(133, 128, 128, 0.8)';
}