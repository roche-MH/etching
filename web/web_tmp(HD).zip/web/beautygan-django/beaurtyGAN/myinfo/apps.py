from django.apps import AppConfig


class MyinfoConfig(AppConfig):
    name = 'myinfo'
