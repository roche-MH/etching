from django.apps import AppConfig


class ImgprocessConfig(AppConfig):
    name = 'imgprocess'
