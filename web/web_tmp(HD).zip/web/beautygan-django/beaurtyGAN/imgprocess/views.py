from django.shortcuts import render
from django.views.generic import TemplateView

class ImgProcessView(TemplateView):
    template_name = 'imgprocess.html'

class InputImgView(TemplateView):
    template_name = 'inputImg.html'