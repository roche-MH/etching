from django.apps import AppConfig


class DetailpicConfig(AppConfig):
    name = 'detailPic'
