from django.apps import AppConfig


class LikefeedConfig(AppConfig):
    name = 'likefeed'
